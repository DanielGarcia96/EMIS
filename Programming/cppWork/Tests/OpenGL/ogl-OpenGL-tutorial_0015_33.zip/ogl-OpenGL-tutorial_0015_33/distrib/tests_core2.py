from utils import *


Clean()

HgUpdate21()
PatchAll()
Build_XCode_64()
RunAll()

Clean()
