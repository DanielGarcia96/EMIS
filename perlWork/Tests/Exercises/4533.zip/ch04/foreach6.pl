#!/usr/bin/perl
# foreach6.pl

use warnings;
use strict;

my @a = qw(John Paul George Ringo);

print "[$_]\n" foreach @a;
