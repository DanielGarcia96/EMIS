#!/usr/bin/perl
# foreach1.pl

use warnings;
use strict;

my $element;

foreach $element ('zero', 'one', 'two') {
    print "the element is: $element\n";
}
