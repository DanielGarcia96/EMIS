#!/usr/bin/perl
# numberlist.pl

use warnings;
use strict;

print(123, 456, 789);
