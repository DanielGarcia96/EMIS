#!/usr/bin/perl
# access.pl

use warnings;
use strict;

print(('salt', 'vinegar', 'mustard', 'pepper')[2]);
print "\n";
