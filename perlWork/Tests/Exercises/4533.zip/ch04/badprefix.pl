#!/usr/bin/perl
# badprefix.pl

use warnings;
use strict;

my @array = (1, 3, 5, 7, 9);
print @array[1];
