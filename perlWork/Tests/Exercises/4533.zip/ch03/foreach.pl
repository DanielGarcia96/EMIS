#!/usr/bin/perl
# foreach.pl

use warnings;
use strict;

my $number;

foreach $number (1 .. 10) {
    print "the number is: $number\n";
}
