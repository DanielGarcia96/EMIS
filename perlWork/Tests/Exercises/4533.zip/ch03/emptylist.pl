#!/usr/bin/perl
# emptylist.pl

use warnings;
use strict;

if ( (()) ) {
   print "Yes, it is.\n";
}
