#!/usr/bin/perl
# while2.pl

use warnings;
use strict;

while (<STDIN>) {
    print "You entered: ";
    print;
}
