#!/usr/bin/perl
# while3.pl

use warnings;
use strict;

my $countdown = 5;

while ($countdown > 0) {
   print "Counting down: $countdown\n";
}
