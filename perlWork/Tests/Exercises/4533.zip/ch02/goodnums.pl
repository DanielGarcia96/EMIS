#!/usr/bin/perl
# goodnums.pl

use warnings;

print 255,        "\n";
print 0377,       "\n";
print 0b11111111, "\n";
print 0xFF,       "\n";
