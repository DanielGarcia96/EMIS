#!/usr/bin/perl
# aside1.pl

use warnings;

print 'ex\\ er\\' , ' ci\' se\'' , "\n";
