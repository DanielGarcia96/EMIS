#!/usr/bin/perl
# bool4.pl

use warnings;

print "Seven is less than or equal to sixteen? ", 7 <= 16, "\n";
print "Two is more than or equal to two? ",       2 >= 2,  "\n";
