#!/usr/bin/perl
# quotes4.pl

use warnings;

print "'\"Hi,\" said Jack. \"Have you read Slashdot today?\"'\n";
