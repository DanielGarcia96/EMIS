#!/usr/bin/perl
# arithop3.pl

use warnings;

print "7 times 15 is ", 7 * 15, "\n";
print "249 divided by 3 is ", 249 / 3, "\n";
