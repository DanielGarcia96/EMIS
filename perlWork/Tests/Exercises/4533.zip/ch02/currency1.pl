#!/usr/bin/perl
# currency1.pl

use warnings;
use strict;

my $yen = 90.45;   # as of 13 November 2009
print "49518 Yen is ", (49_518/$yen), " dollars\n";
print "360 Yen is   ", (   360/$yen), " dollars\n";
print "30510 Yen is ", (30_510/$yen), " dollars\n";
