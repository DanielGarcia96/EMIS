#!/usr/bin/perl
# string4.pl

use warnings;

print "Ba" . "na" x 4*3 ,"\n";
print "Ba" . "na" x (4*3) ,"\n";
