#!/usr/bin/perl
# number1.pl

use warnings;

print 25, -4;
