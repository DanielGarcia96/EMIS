#!/usr/bin/perl
# arithop4.pl

use warnings;

print 3 + 7 * 15, "\n";
