#!/usr/bin/perl
# badnums.pl

use warnings;

print 255,        "\n";
print 0378,       "\n";
print 0b11111112, "\n";
print 0xFG,       "\n";
