#!/usr/bin/perl
# quotes2.pl

use warnings;

print "C:\\WINDOWS\\Media\\\n";
print 'C:\WINDOWS\Media\ ', "\n";
