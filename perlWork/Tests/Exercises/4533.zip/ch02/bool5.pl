#!/usr/bin/perl
# bool5.pl

use warnings;

print "Compare six and nine? ",    6 <=> 9, "\n";
print "Compare seven and seven? ", 7 <=> 7, "\n";
print "Compare eight and four? ",  8 <=> 4, "\n";
