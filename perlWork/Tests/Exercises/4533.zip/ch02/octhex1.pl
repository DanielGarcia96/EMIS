#!/usr/bin/perl
# octhex1.pl

use warnings;

print "0x30\n";
print "030\n";
