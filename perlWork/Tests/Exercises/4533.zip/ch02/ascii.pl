#!/usr/bin/perl
# ascii.pl

use warnings;

print "A # has ASCII value ", ord("#"), "\n";
print "A * has ASCII value ", ord("*"), "\n";
