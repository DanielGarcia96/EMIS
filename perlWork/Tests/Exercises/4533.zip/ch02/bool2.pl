#!/usr/bin/perl
# bool2.pl

use warnings;

print "So, two isn't equal to four? ", 2 != 4, "\n";
