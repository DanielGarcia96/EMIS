#!/usr/bin/perl
# bitop1.pl

use warnings;

print "51 ANDed with 85 gives us ", 51 & 85, "\n";
