#!/usr/bin/perl
# autoconvert.pl

use warnings;

print "0.25" * 4, "\n";
