#!/usr/bin/perl
# string1.pl

use warnings;

print "Four sevens are ". 4*7 ."\n";
