#!/usr/bin/perl
# varint3.pl

use warnings;
use strict;

my $name = "fred";
my $salutation = "Dear $name,";
print $salutation, "\n";
