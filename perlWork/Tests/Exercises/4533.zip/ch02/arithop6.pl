#!/usr/bin/perl
# arithop6.pl

use warnings;

print((3 + 7) * 15, "\n");
