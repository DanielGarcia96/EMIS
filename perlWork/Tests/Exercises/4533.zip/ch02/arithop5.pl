#!/usr/bin/perl
# arithop5.pl

use warnings;

print (3 + 7) * 15, "\n";
