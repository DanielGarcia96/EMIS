#!/usr/bin/perl
# bool3.pl

use warnings;

print "Five is more than six? ",      5 >  6, "\n";
print "Seven is less than sixteen? ", 7 < 16, "\n";
print "Two is equal to two? ",        2 == 2, "\n";
print "One is more than one? ",       1 >  1, "\n";
print "Six is not equal to seven? ",  6 != 7, "\n";
