#!/usr/bin/perl
# number2.pl

use warnings;

print 25, " ", -4, "\n";
