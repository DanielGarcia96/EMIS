#!/usr/bin/perl
# varint2.pl

use warnings;
use strict;

my $name = "fred";
print 'My name is $name\n';
