#!/usr/bin/perl
# string2.pl

use warnings;

print "GO! " x 3, "\n";
