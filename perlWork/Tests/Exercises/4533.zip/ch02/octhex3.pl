#!/usr/bin/perl
# octhex3.pl

use warnings;

print hex("FFG"), "\n";
print oct("178"), "\n";
