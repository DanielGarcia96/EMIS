#!/usr/bin/perl
# number3.pl

use warnings;

print 25_000_000, " ", -4, "\n";
