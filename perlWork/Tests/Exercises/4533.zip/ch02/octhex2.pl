#!/usr/bin/perl
# octhex2.pl

use warnings;

print hex("0x30"), "\n";
print oct("030"), "\n";
