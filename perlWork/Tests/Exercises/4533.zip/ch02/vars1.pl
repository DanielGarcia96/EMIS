#!/usr/bin/perl
# vars1.pl

use warnings;

$name = "fred";
print "My name is ", $name, "\n";
