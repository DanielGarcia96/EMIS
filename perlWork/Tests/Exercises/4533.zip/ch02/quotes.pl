#!/usr/bin/perl
# quotes.pl

use warnings;

print '\tThis is a single quoted string.\n';
print "\tThis is a double quoted string.\n";
