#!/usr/bin/perl
# arithop1.pl

use warnings;

print 69 + 118, "\n";
