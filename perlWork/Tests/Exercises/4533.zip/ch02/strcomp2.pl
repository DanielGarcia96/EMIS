#!/usr/bin/perl
# strcomp2.pl

use warnings;

print "Test one: ", "four" eq "six", "\n";
print "Test two: ", "four" == "six", "\n";
