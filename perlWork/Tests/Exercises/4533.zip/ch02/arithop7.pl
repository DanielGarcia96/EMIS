#!/usr/bin/perl
# arithop7.pl

use warnings;

print 2**4, " ", 3**5, " ", -2**4, "\n";
