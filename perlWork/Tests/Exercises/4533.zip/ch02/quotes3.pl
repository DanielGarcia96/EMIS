#!/usr/bin/perl
# quotes3.pl

use warnings;

print "It's as easy as that.\n";
print '"Stop," he cried.', "\n";
