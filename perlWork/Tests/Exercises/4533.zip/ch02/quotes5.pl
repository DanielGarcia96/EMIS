#!/usr/bin/perl
# quotes5.pl

use warnings;

print qq/'"Hi," said Jack. "Have you read Slashdot today?"'\n/;
