#!/usr/bin/perl
# vars2.pl

use warnings;

$name = "fred";
print "My name is ",               $name, "\n";
print "It's still ",               $name, "\n";
$name = "bill";
print "Well, actually, now it's ", $name, "\n";
$name = "fred";
print "No, really, now it's ",     $name, "\n";
