#!/usr/bin/perl
# bitop2.pl

use warnings;

print "NOT 85 is ", ~85, "\n";
