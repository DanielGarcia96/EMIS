#!/usr/bin/perl
# varint4.pl

use warnings;
use strict;

my $times = 8;
print "This is the ${times}th time.\n";
