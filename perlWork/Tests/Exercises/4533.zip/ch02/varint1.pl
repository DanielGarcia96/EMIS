#!/usr/bin/perl
# varint1.pl

use warnings;
use strict;

my $name = "fred";
print "My name is $name\n";
