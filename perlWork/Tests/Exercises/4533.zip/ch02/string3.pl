#!/usr/bin/perl
# string3.pl

use warnings;

print "Ba" . "na" x 4 ,"\n";
