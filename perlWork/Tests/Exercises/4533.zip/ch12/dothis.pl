#!/usr/bin/perl
# dothis.pl

use warnings;
use strict;

my $var = "Been there, done that, got the T–shirt";
do "printit.pl";
