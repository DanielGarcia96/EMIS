#!/usr/bin/perl
# cantload.pl

use warnings;
use strict;

require "not_there.pl";
