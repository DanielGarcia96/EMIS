# printit.pl

use warnings;

print $var;
print "this should go to standard output...\n";
