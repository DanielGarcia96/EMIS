#!/usr/bin/perl
# strict2.pl

use warnings;
use strict;

$main::x = 10;
print $main::x, "\n";
