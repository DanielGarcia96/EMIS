#!/usr/bin/perl
# strict1.pl

use warnings;
use strict;

$x = 10;
print $x;
