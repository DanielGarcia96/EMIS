#!/usr/bin/perl
# hello1.pl

use warnings;

print "Hello, world!\n";
