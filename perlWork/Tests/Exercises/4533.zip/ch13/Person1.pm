package Person1;
# Person1.pm

# Class for storing data about a person

use strict;

1;
