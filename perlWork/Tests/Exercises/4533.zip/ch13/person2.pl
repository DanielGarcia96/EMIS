#!/usr/bin/perl
# person2.pl

use warnings;
use strict;
use Person2;

my $person = Person2->new();
