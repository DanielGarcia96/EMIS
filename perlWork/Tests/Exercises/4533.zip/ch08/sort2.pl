#!/usr/bin/perl
# sort2.pl

use warnings;
use strict;

my @text = <>;

print sort @text;
