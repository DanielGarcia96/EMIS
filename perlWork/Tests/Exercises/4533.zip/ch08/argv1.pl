#!/usr/bin/perl
# argv1.pl

use warnings;
use strict;

print "[$_]\n" foreach @ARGV;
