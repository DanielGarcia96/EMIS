#!/usr/bin/perl
# diamond1.pl

use warnings;
use strict;

while (<>) {
    print "text read: $_"
}
