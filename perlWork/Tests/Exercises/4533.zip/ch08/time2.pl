#!/usr/bin/perl
# time2.pl

use warnings;
use strict;

$| = 1;
foreach (1..20) {
   print ".";
   sleep 1;
}
print "\n";
