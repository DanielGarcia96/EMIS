#!/usr/bin/perl
# time1.pl

use warnings;
use strict;

foreach (1..20) {
   print ".";
   sleep 1;
}
print "\n";
