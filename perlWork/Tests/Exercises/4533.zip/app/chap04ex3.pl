#!/usr/bin/perl
# chap04ex3.pl

use warnings;
use strict;

my @a = ('aa' .. 'bb');
print "first array:\n";
print "@a\n";

@a = ('a0' .. 'b9');
print "------------\n";
print "second array:\n";
print "@a\n";
