#!/usr/bin/perl
# chap08ex2.pl

use warnings;
use strict;

unless (@ARGV) {
    @ARGV = qw(file1.dat file2.dat file3.dat);
}

print <>;
