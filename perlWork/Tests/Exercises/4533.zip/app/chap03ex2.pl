#!/usr/bin/perl
# chap03ex2.pl

use warnings;
use strict;

for (my $i = 1; $i <= 10; $i++) {
    print "$i square is: ", $i*$i, "\n";
}
