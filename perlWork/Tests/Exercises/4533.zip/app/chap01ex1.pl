#!/usr/bin/perl
# chap01ex1.pl

use warnings;

print "Hi Mom.\nThis is my second program.\n";
