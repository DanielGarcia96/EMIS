#!/usr/bin/perl
# hello.pl

use warnings;
use strict;

print "Content-Type: text/plain\n";
print "\n";
print "hello, world!\n";
